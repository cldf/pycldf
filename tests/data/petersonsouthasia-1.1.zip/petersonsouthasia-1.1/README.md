# Towards a linguistic prehistory of eastern-central South Asia

[![Build Status](https://travis-ci.org/cldf-datasets/ewave.svg?branch=master)](https://travis-ci.org/cldf-datasets/ewave)

Cite the source dataset as

> Peterson, J. (2017). Fitting the pieces together – Towards a linguistic prehistory of eastern-central South Asia (and beyond). Journal of South Asian Languages and Linguistics, 4(2), pp. 211-257. doi:10.1515/jsall-2017-0008

Available online at https://doi.org/10.1515/jsall-2017-0008
